package edu.mum.cs.cs425.ahacarrentalservice.model;

public enum ProfileStatus {
	PENDING,
	APPROVED
}
