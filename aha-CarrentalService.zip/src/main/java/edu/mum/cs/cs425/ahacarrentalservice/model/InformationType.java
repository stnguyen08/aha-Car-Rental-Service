package edu.mum.cs.cs425.ahacarrentalservice.model;

public enum InformationType {
    INFORMATION,
    ERROR,
    WARNING,
    FATAL
}
