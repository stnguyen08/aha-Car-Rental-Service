package edu.mum.cs.cs425.ahacarrentalservice.model;


public enum Color {
    BLACK,
    WHITE,
    RED,
    GREEN,
    BLUE,
    SILVER
}
