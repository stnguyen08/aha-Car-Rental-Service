package edu.mum.cs.cs425.ahacarrentalservice.model;

public enum AnalysisStatus {
    PENDING,
    APPROVED,
    REJECTED;
}
