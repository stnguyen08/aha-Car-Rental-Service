
INSERT INTO car_brand (id, logo_url, name) VALUES (1,'/images/logo/carbrand/ford.gif',	'Ford');
INSERT INTO car_brand (id, logo_url, name) VALUES (2,'/images/logo/carbrand/BMW.gif',	'BMW');
INSERT INTO car_brand (id, logo_url, name) VALUES (3,'/images/logo/carbrand/audi.gif',	'Audi');

INSERT INTO car_model (id, name, brand_id) VALUES (1,'Fusion',1);
INSERT INTO car_model (id, name, brand_id) VALUES (2,'Focus',1);
INSERT INTO car_model (id, name, brand_id) VALUES (3,'F-150',1);
INSERT INTO car_model (id, name, brand_id) VALUES (4,'F-250',1);
INSERT INTO car_model (id, name, brand_id) VALUES (5,'Mustang',1);

INSERT INTO car_model (id, name, brand_id) VALUES (6,'328i',2);
INSERT INTO car_model (id, name, brand_id) VALUES (7,'428i',2);
INSERT INTO car_model (id, name, brand_id) VALUES (8,'M3',2);
INSERT INTO car_model (id, name, brand_id) VALUES (9,'X5',2);
INSERT INTO car_model (id, name, brand_id) VALUES (10,'535i',2);

INSERT INTO car_model (id, name, brand_id) VALUES (11,'A4',3);
INSERT INTO car_model (id, name, brand_id) VALUES (12,'A5',3);
INSERT INTO car_model (id, name, brand_id) VALUES (13,'A6',3);
INSERT INTO car_model (id, name, brand_id) VALUES (14,'A7',3);
INSERT INTO car_model (id, name, brand_id) VALUES (15,'A8',3);
